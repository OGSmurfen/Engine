﻿
using var game = new Monogame.ImGuiNetSamples.Game1();
game.Run();
